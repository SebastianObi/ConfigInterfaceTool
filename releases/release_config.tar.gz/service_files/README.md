### PUT_YOUR_SERVICE_DEFINITIONS_HERE
This folder is used to configure the services. The processing takes place in alphabetical order.