### PUT_YOUR_DEFAULT_CONFIG-FILES_HERE
The configuration files of the applications to be used are stored in this folder. The files are defined in the config file in the config_files folder.