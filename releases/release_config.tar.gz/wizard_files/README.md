### PUT_YOUR_WIZARD_DEFINITIONS_HERE
This folder is used to configure the wizards. The processing takes place in alphabetical order.